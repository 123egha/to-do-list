## express-mongoDB-TodoList
Todo List made from udemy course: 2021 Complete Web Develoment course from angela yu

## technologies

* node.js,
* express,
* ejs,
* MongoDB, 
* mongoose, 
* bodyParser, 
* loadash, 

## instalation
```node.js
  git clone https://github.com/Leonardpepa/express-mongoDB-TodoList.git
  run npm instal
  run mongod in the terminal
  run node app.js
  open localhost:3000
  ```
## requirements
  node.js
  MongoDB


## live: https://serene-lowlands-60843.herokuapp.com
### hosted on heroku with mongoDB ATLAS
